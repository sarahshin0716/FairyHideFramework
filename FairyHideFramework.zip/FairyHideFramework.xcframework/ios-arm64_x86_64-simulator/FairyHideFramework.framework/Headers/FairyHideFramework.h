//
//  FairyHideFramework.h
//  FairyHideFramework
//
//  Created by Claire Shin on 2022/12/26.
//

#import <Foundation/Foundation.h>

//! Project version number for FairyHideFramework.
FOUNDATION_EXPORT double FairyHideFrameworkVersionNumber;

//! Project version string for FairyHideFramework.
FOUNDATION_EXPORT const unsigned char FairyHideFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FairyHideFramework/PublicHeader.h>


